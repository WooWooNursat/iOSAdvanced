//
//  AlarmApp.swift
//  Alarm
//
//  Created by Nursat on 18.03.2021.
//

import SwiftUI

@main
struct AlarmApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
